from django.shortcuts import render
from .models import *

def roomList(request):
    room = Room.objects.filter(available = True)
    return render(request, 'room/list.html', {'room': room,})

def roomDetail(request,slug):
    room = Room.objects.filter(slug=slug)
    return render(request, 'room/detail.html', {'room': room, 'slug': slug,})
