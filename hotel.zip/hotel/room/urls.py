from django.urls import path
from . import views


urlpatterns = [
    path('', views.roomList, name = 'roomList'),
    path('<slug:slug>/', views.roomDetail, name = 'roomDetail'),

]
