from django.contrib import admin
from .models import *

@admin.register(Booking)
class AdminBooking(admin.ModelAdmin):
    list_display = ('id','user', 'room', 'dayIn', 'dayOut', 'price')
    list_display_links = ('id', 'user', 'room')
