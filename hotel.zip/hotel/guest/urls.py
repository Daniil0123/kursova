from django.urls import path
from .views import UserPasswordChange
from . import views

urlpatterns = [
    path('login-user/', views.loginUser, name='login'),
    path('logout-user/', views.logoutUser, name='logout'),
    path('register-user/', views.registerUser, name='register'),
    path('password-change/', UserPasswordChange.as_view(), name='passwordChange'),
]
